# Tethered-Air-Ground-MCS
这是一个致力于把“搭载有系留无人机的无人车”用在室外群体感知覆盖的工作，进度如下：

###### Meeting 20221026
- [ ] 有谁一起做呀？能不能做？怎么做的更好？

## :page_facing_up: Description

众所周知，无人机是有[差别](https://www.ziyanuav.com/info/792.html)的。近两年看到的很多早晚能落地的应用，比如[消防无人直升机、消防系留无人机](https://www.sohu.com/a/582462351_163726)，大家也可以去知乎、谷歌搜一下系留无人机（tethered drone）的少量新闻，可以看到它相比非系留无人机的主要优点就是：电量充足、可装备更重的设备、信号传输快，能在应急场景实现真正意义的7x24h感知。然而，感觉学术界缺少相应的场景支持，综述或文章也不多，比较相关的有[文章1](https://arxiv.org/abs/2107.08169)、[文章2](https://ieeexplore.ieee.org/document/9205314)、[文章3](https://ieeexplore.ieee.org/document/9921200)、[文章4](https://ieeexplore.ieee.org/document/9839554)、[文章5](https://ieeexplore.ieee.org/document/9739716)、[文章6](https://ieeexplore.ieee.org/document/9847223)，有空可以一起看看细节。其中，有一些都涉及到“空天地”了，可以先收收哈，留着以后接着拍脑袋。我能够看到的一些比较主流的应用，应该还是把UAV挂在楼顶上或者挂在固定基站上，而线缆的作用也有只提供电力、以及顺便提供空地数据传输的不同功能。

![](https://i.imgur.com/lNP2o9T.png)


目前我也看到一些搭载有系留无人机的无人车demo，但是比较[偏军用](https://uasweekly.com/2020/04/13/sky-sapience-introduces-hovermast-lite-the-next-generation-of-tethered-uav-platform/)。我在想能不能类似这个demo，做一个无人车拽着系留无人机对rural areas进行感知的场景，或者做灾后救援也可以，Tethered UAV systems有更多的民用场景只是时间问题。


![](https://i.imgur.com/LwA45ov.jpg)


本文要做的应该就是一个多无人车各自携带系留无人机的应用，我们可能的创新点有（纯拍脑袋，你们一定要在多读书的基础上完善）：
- [ ] 在system model的第一方面，不需要考虑小叶Air-Ground NOMA那么复杂的通信模型了，甚至文章可以基于王宇之前的几个ICDE，直接就不要通信，简化采集范围建模。如果非要加通信（KDD没必要太复杂的通信），那可以考虑空地电缆集成了光纤，没有无人机到无人车之间输出传输的channel，于是可以将较远地区的信号以UAV ad-hoc network的方式逐无人机转发，并单独考虑纯UAV网络中的SINR。至于无人车是否有数据采集能力，可以有，但最好不要考虑无人车之间传输数据的地面网络建模，地面不像天上、海上，channel model应该不能太easy。
- [ ] 在system model的第二方面，如上图，可以follow小叶自己的第一篇ICDE工作，依然假设无人车只能沿着道路开，无人机可以在天上飞，两者有一根线连着。此时的动作空间要好好设计，最好还是设置成离散的形式。
- [ ] 在system model的第三方面，如上图，可以follow小叶合作的那篇INFOCOM工作，依然假设地面的mobile user是移动的，让无人车拉着无人机去采集数据，此时可以继续引入之前AoI继续作为metric。
- [ ] 至于你所用的MDP建模与solution，感觉这个文章可以先尝试将UAV、UGV都当做独立智能体，考虑魔改这个“[Scalable Model-based Policy Optimization for Decentralized Networked Systems](https://github.com/PKU-MARL/Model-Based-MARL)”的文章中的代码，但这些智能体之间可能不需要全联通，应该会有更加复杂的constrain。此外，考虑到实际问题，UAV、UGV不太可能是独立控制的，毕竟他们本来就是一体，我觉得更合理的情况应该是**认为一组UAV和UGV是一个智能体，这个智能体的动作是一个离散的action space，维度包括移动飞机和移动车，即：不允许同时移动无人机和移动车**。虽然你可能会觉得这样就不cool了，但考虑到现在的系留无人机主要都是放在固定的基站和终端上的，两端都移动是unsafe且应该通信不太稳定的。我觉得可以先从后者做起，不论是怎样定义一个agent，我觉得都可以借鉴这些networked MARL有关的代码，比较适合写文章，但效果不一定有多好。或者保证效果+面向KDD的话，还是简单一点，就还是用[对抗通信的代码](https://github.com/proroklab/adversarial_comms)，合作部分为solution，引入1-N个self-interested agents为ablation实验，强调在实时信号覆盖的任务中智能体合作控制的重要性，这也是一些评委可能通常会问到的问题。
- [ ] 在system model的第四方面，这方面是结合第一点的，我其实建议这个文章是使用一些networked but decentralized control的方式来解决，但通信还是尽量简单，最多也就SINR推个range得了，最好不要考虑无人机之间互相转发形成自组网。如果你一定要考虑，你就还需要一个中心基站去接收最终的数据，那在表征的时候可能会比较难做，因为这时候未必是单步的优化问题，中心基站的位置会带来一些不太容易泛化的问题。。。不如还是做DTDE的一些settings，这样王昊可以和你们一起探讨。





## :wrench: Dependencies
- Python == 3.6 (Recommend to use [Anaconda](https://www.anaconda.com/download/#linux) or [Miniconda](https://docs.conda.io/en/latest/miniconda.html))
- [PyTorch == 1.11.0](https://pytorch.org/)
- xxxxxx
### Installation
1. Clone repo
    ```bash
    git clone https://github.com/superboySB/Tethered-Air-Ground-MCS.git
    cd Tethered-Air-Ground-MCS
    ```

2. xxx
   

## :computer: Training

- Train

```sh
python main.py xxxx
```

## :checkered_flag: Testing

- Test (Example)

```sh
python main.py xxxx
```


- Visualization

```sh
python main.py xxxx
```


## :e-mail: Contact
If you have any question, please email `3120215520@bit.edu.cn`.

## :book: CITATION
If you find our work helpful in your research, please consider citing:
```
Hope that we can have a good paper instead of a shit book.
```

## :clap: ACKNOWLEDGMENT

In this repository, we use parts of the implementation from xxx，xxx and xxx.
